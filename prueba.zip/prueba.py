
from telegram import (ParseMode)
from telegram.ext import (Updater, CommandHandler)
from telebot import util
from telebot.types import InlineKeyboardButton
from telebot.types import InlineKeyboardMarkup


import logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',level=logging.INFO)
logger = logging.getLogger(__name__)

def error_callback(update, context):
    logger.warning('Update "%s" caused error "%s"', update, context.error)

def start(update, context):

	# Enviar un mensaje a un ID determinado.
    name = update.message.from_user.username
    update.message.reply_text(f'Hola {name} esto es el Forn de Cabrianes')

	# Podemos llamar a otros comandos, sin que se haya activado en el chat (/help).
	#coin(update, context)

def coin(update, context):
    print("hola")
    markup = InlineKeyboardMarkup(row_width = 2)
    b1 = InlineKeyboardButton("Prueba")
    markup.add(b1)
    update.send_message(context.chat.id, "Prueba", reply_markup=markup) 

def main():
	TOKEN="5714810199:AAEKWVMMG2OUz8VHR_CRhEXhIKUkHVapKLo"
	updater=Updater(TOKEN, use_context=True)
	dp=updater.dispatcher

	# Eventos que activarán nuestro bot.
	# /comandos
	dp.add_handler(CommandHandler('start',	start))
	dp.add_handler(CommandHandler('coin',	coin))

	dp.add_error_handler(error_callback)
    # Comienza el bot
	updater.start_polling()
    # Lo deja a la escucha. Evita que se detenga.
	updater.idle()


if __name__ == '__main__':
	print(('[Nombre del bot] Start...'))
	main()